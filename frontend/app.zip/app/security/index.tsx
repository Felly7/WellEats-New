// app/security/index.tsx
import React from 'react';
import { View, Text, StyleSheet, Switch, useColorScheme } from 'react-native';

export default function SecurityScreen() {
  const isDarkMode = useColorScheme() === 'dark';
  // you can hook these up to SecureStore or backend
  const [twoFactor, setTwoFactor] = React.useState(false);
  const [biometric, setBiometric] = React.useState(false);

  return (
    <View style={[styles.container, isDarkMode && styles.darkBg]}>
      <Text style={[styles.header, { color: isDarkMode ? '#FFF' : '#000' }]}>
        Security & Privacy
      </Text>

      <View style={styles.row}>
        <Text style={[styles.label, { color: isDarkMode ? '#FFF' : '#000' }]}>
          Two-Factor Authentication
        </Text>
        <Switch value={twoFactor} onValueChange={setTwoFactor} />
      </View>

      <View style={styles.row}>
        <Text style={[styles.label, { color: isDarkMode ? '#FFF' : '#000' }]}>
          Biometric Login
        </Text>
        <Switch value={biometric} onValueChange={setBiometric} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, padding:16, backgroundColor:'#FFF' },
  darkBg:    { backgroundColor:'#121212' },
  header:    { fontSize:22, fontWeight:'bold', marginBottom:16 },
  row:       { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingVertical:12 },
  label:     { fontSize:16 },
});
