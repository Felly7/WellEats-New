// app/notifications/index.tsx
import React from 'react';
import { View, Text, StyleSheet, Switch, useColorScheme } from 'react-native';

export default function NotificationsScreen() {
  const isDarkMode = useColorScheme() === 'dark';
  const [push, setPush] = React.useState(true);
  const [email, setEmail] = React.useState(false);

  return (
    <View style={[styles.container, isDarkMode && styles.darkBg]}>
      <Text style={[styles.header, { color: isDarkMode ? '#FFF' : '#000' }]}>
        Notification Settings
      </Text>

      <View style={styles.row}>
        <Text style={[styles.label, { color: isDarkMode ? '#FFF' : '#000' }]}>
          Push Notifications
        </Text>
        <Switch value={push} onValueChange={setPush} />
      </View>

      <View style={styles.row}>
        <Text style={[styles.label, { color: isDarkMode ? '#FFF' : '#000' }]}>
          Email Notifications
        </Text>
        <Switch value={email} onValueChange={setEmail} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, padding:16, backgroundColor:'#FFF' },
  darkBg:    { backgroundColor:'#121212' },
  header:    { fontSize:22, fontWeight:'bold', marginBottom:16 },
  row:       { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingVertical:12 },
  label:     { fontSize:16 },
});
